<?php
$email = $_POST['email'];
$password = $_POST['password'];
//database connection here
$con = new mysli("localhost","root","","test");
if($con->connect_error) {
  div("Failed to connect : " .$con->connect-error);
} else {
  $stmt = $con->prepare("select *form registration where email = ?");
  $stmt->bind_param("s",$email);
  $stmt->execute();
  $stmt_result = $stmt->get_result();
  if($stmt_result->num_rows > 0) {
    echo "<h2>login successfully</h2>"";
  } else {
    echo "<h2>invalid Email or password</h2>";
  } else {
    echo "<n2>invalid email or password</h2>";
  }
}
?>
